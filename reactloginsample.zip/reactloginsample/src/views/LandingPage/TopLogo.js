import React from 'react';
import Instacolrlogo from '../../../src/assets/img/logo-instacolr.svg';

export default function TopLogo(props) {
  return (
    <div className="App">
      <img src={Instacolrlogo} alt="Instacolor Logo" />
    </div>
  );
}

