const homCentContentStyle = {
  homCentContent: {
    height: "90vh",
    maxHeight: "1000px",
    overflow: "hidden",
    position: "relative",
    backgroundPosition: "center center",
    backgroundSize: "cover",
    margin: "0",
    padding: "0",
    right: "0px",
    left: "0px",
    border: "0",
    display: "flex",
    alignItems: "center",
  },
  filter: {
    "&:before": {
      background: "rgba(0, 0, 0, 0.5)"
    },
    "&:after,&:before": {
      position: "absolute",
      zIndex: "1",
      width: "100%",
      height: "100%",
      display: "block",
      left: "0",
      top: "0",
      content: "''"
    }
  },
  small: {
    height: "380px"
  },
  subtitle: {
    fontsize: "40pt !important",
    lineheight: "48px",
    color: "#444 !important",
    fontweight: "800px !important",
    letterSpacing: "0.4px",
    margin: "0px 0px 0px 0px",
    padding: "20px 10px 10px 10px",
    display:"inline-block",
    "@media (max-width: 375px)": {
      textAlign: "center"
    },    
  },
  subtitlecont: {
    fontsize: "20px !important",
    fontweight: "800px !important",
    fontstyle: "bold",
    lineheight: "24px !important",
    color: "#444 !important",
    margin: "10px 0px 0px 0px",
    padding: "0px 10px 10px 10px",
    display:"inline-block",
    "@media (max-width: 375px)": {
      textAlign: "center"
    },     
  },
  column1box: {
    float: "left",
    padding: "0 10px",
    width: "60%",
    "@media (max-width: 375px)": {
      display: "inherit",
      width: "auto !important",
    },
    "@media only screen and (min-device-width: 1024px) and (max-device-width: 1366px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)": {
      width: "57%"
    }
  },
  h2: {
    margin: "20px",
    padding: "0px"
  },
  column2box: {
    float: "left",
    padding: "10px 10px",
    width: "38%",    
    backgroundColor: "#fff",
    marginTop: "120px",
    marginLeft: "20px",
    opacity: 0.7, 
    "@media (max-width: 375px)": {
      display: "inherit",
      width: "auto !important",
      marginTop: "50px",
    },
    "@media only screen and (min-device-width: 1024px) and (max-device-width: 1366px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)": {
      width: "40%"
    }
  },
  column3box: {
    float: "right",
    padding: "0 10px",
    width: "60%",
    "@media (max-width: 375px)": {
      display: "inherit",
      width: "auto !important"
    },
    "@media only screen and (min-device-width: 1024px) and (max-device-width: 1366px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)": {
      width: "57%"
    }
  },
  column4box: {
    float: "left",
    padding: "0px 10px",
    width: "38%",    
    backgroundColor: "#fff",
    marginTop: "100px",    
    marginLeft: "20px",
    opacity: 0.7, 
    "@media (max-width: 375px)": {
      display: "inherit",
      width: "auto !important",
      marginTop: "50px",
    },
    "@media only screen and (min-device-width: 1024px) and (max-device-width: 1366px) and (-webkit-min-device-pixel-ratio: 2) and (orientation: portrait)": {
      width: "40%"
    }
  },
  boxes: {
    content: "",
    display: "table",
    clear: "both"
  },
  padspace: {
    margin: "80px 0px 0px 0px"
  }
};

export default homCentContentStyle;
