import React from 'react';
import ReactDOM from 'react-dom';
import { createBrowserHistory } from "history";
import { Router, Route, Switch } from "react-router-dom";
import 'bootstrap/dist/css/bootstrap.min.css';
import { Provider } from 'react-redux';
import "assets/scss/material-kit-react.scss?v=1.9.0";
import "index.css";
import { MuiThemeProvider, createMuiTheme } from '@material-ui/core/styles';
import HomePage from "views/LandingPage/HomePage.js";
import LoginPage from "views/LoginPage/LoginPage.js";


const theme = createMuiTheme({ typography: { fontFamily: [ 'Lato' ].join(','), }, })
var hist = createBrowserHistory();

ReactDOM.render( 
  <Router history={hist}>
    <Switch>
      {/* <Route path="/landing-page" component={LandingPage} />
      <Route path="/profile-page" component={ProfilePage} /> */}
      <Route path="/login-page" component={LoginPage} />
      <Route path="/" component={HomePage} />
    </Switch>
  </Router>,
  document.getElementById("root")
);

// If you want your app to work offline and load faster, you can change
// unregister() to register() below. Note this comes with some pitfalls.
// Learn more about service workers: https://bit.ly/CRA-PWA
//serviceWorker.unregister();
