import React from "react";
// @material-ui/core components
import { Link } from "react-router-dom";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import { makeStyles } from "@material-ui/core/styles";
import InputAdornment from "@material-ui/core/InputAdornment";
import Icon from "@material-ui/core/Icon";
// @material-ui/icons
import Email from "@material-ui/icons/Email";
import People from "@material-ui/icons/People";
// core components
import Header from "components/Header/Header.js";
import HeaderLinks from "components/Header/HeaderLinks.js";
import Footer from "components/Footer/Footer.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Button from "components/CustomButtons/Button.js";
import Card from "components/Card/Card.js";
import CardBody from "components/Card/CardBody.js";
import CardHeader from "components/Card/CardHeader.js";
import CardFooter from "components/Card/CardFooter.js";
import CustomInput from "components/CustomInput/CustomInput.js";
import Checkbox from "@material-ui/core/Checkbox";
import Visibility from "@material-ui/icons/Visibility";

import Check from "@material-ui/icons/Check";

import styles from "assets/jss/material-kit-react/views/loginPage.js";
import navbarStyles from "assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js";
import centContStyles from "assets/jss/material-kit-react/components/HomCentContentStyle.js";

import basicStyles from "assets/jss/material-kit-react/views/componentsSections/basicsStyle.js";

import image from "assets/img/background1.jpg";

// const useStyles = makeStyles(styles);

import Instacolrlogo from '../../../src/assets/img/logo-instacolr.svg';
import LoginForm from './LoginForm';


export default function LoginPage(props) {

const useStyles = makeStyles(styles);
const useNavStyles = makeStyles(navbarStyles);
const useCentContStyles = makeStyles(centContStyles);
const useBasicStyles = makeStyles(basicStyles);

   const [cardAnimaton, setCardAnimation] = React.useState("cardHidden");
    setTimeout(function () {
      setCardAnimation("");
    }, 700);
    const classes = useStyles();
    const inputClasses = useBasicStyles();
    const navClasses = useNavStyles();
    const centContClasses = useCentContStyles();
    // const { ...rest } = props;
    const [checked, setChecked] = React.useState([24, 22]);
    const [selectedEnabled, setSelectedEnabled] = React.useState("b");
    const [checkedA, setCheckedA] = React.useState(true);
    const [checkedB, setCheckedB] = React.useState(false);
    const handleToggle = value => {
      const currentIndex = checked.indexOf(value);
      const newChecked = [...checked];

      if (currentIndex === -1) {
        newChecked.push(value);
      } else {
        newChecked.splice(currentIndex, 1);
      }
      setChecked(newChecked);
    };


  return (
    <div>
      <Header
        brand={<div className="App">
          <img src={Instacolrlogo} alt="Instacolor Logo" />
        </div>}
        rightLinks={
          <List className={navClasses.list}>
            <ListItem className={navClasses.listItem}>
              <Link to={"/login-page"} className={classes.link}><Button color="primary">Log In</Button></Link>
            </ListItem>
          </List>
        }
        fixed
      />
      <div style={{
        backgroundImage: "url(" + image + ")",
        backgroundSize: "cover",
        backgroundPosition: "top center"
      }}
      >
        <div className={classes.container}>
          <GridContainer justify="center">
            <GridItem xs={12} sm={12} md={12}>
               <Card className={classes[cardAnimaton]}>
                <LoginForm />
              </Card>
            </GridItem>
          </GridContainer>
        </div>
        <Footer />
      </div>
    </div>
  );
}