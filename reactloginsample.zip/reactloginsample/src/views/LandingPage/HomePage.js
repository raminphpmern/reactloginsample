import React from "react";
// nodejs library that concatenates classes
import classNames from "classnames";
// react components for routing our app without refresh
import { Link } from "react-router-dom";
// @material-ui/core components
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import Button from "components/CustomButtons/Button.js";
import { makeStyles } from "@material-ui/core/styles";
// core components
import Header from "components/Header/Header.js";
import Footer from "components/Footer/Footer.js";
import GridContainer from "components/Grid/GridContainer.js";
import GridItem from "components/Grid/GridItem.js";
import Parallax from "components/Parallax/Parallax.js";
import HomCentContent from "components/HomCentContent/HomCentContent.js";
// sections for this page
// import Instacolrlogo from '../../../src/assets/img/logo-instacolr.svg';
import Instacolrlogo from 'assets/img/logo-instacolr.svg';
import Avientlogo from '../../../src/assets/img/logo-avient.svg';
import AvientCLogo from '../../../src/assets/img/c-logo.png';
import placeholder1 from '../../../src/assets/img/instacolr-requirements-masterbatch-sample.png';
import placeholder2 from '../../../src/assets/img/instacolr-target-colr.png';
import placeholder3 from '../../../src/assets/img/instacolr-product-proposals.png';
import placeholder4 from '../../../src/assets/img/instacolr-follow-up-actions.png';


import styles from "assets/jss/material-kit-react/views/components.js";
import navbarStyles from "assets/jss/material-kit-react/views/componentsSections/navbarsStyle.js";
import centContStyles from "assets/jss/material-kit-react/components/HomCentContentStyle.js";

const useStyles = makeStyles(styles);
const useNavStyles = makeStyles(navbarStyles);
const useCentContStyles = makeStyles(centContStyles);


export default function Components(props) {
  const classes = useStyles();
  const navClasses = useNavStyles();
  const centContClasses = useCentContStyles();
  const {...rest} = props;
  return (
    <div>
      <Header
            brand={<div className="App">
            <img src={Instacolrlogo} alt="Instacolor Logo" />
          </div>}
            leftLinks={
              <List className={navClasses.list}>
              <ListItem className={navClasses.listItem}>
                <Link to={"/contact-us"} className={classes.link}>My Account</Link>
              </ListItem>
              </List>
            }
            rightLinks={
              <List className={navClasses.list}>
                <ListItem className={navClasses.listItem}>
                  <Link to={"/contact-us"} className={classes.link}>Contact Us</Link>
                </ListItem>
                <ListItem className={navClasses.listItem}>
                <Link to={"/login-page"} className={classes.link}><Button color="primary">Log In</Button></Link>
                </ListItem>
              </List>
            }
            fixed
          />
       <Parallax image={require("assets/img/background1.jpg")}>
        <div className={classes.container}>
          <GridContainer>
            <GridItem>
              <div className={classes.brand}>
                <h1 className={classes.title}>On the Spot <br />Color Matching</h1>
                <h3 className={classes.subtitle}>
                Meet Instacolr, our iPad app that will cut your development time from weeks to minutes.
                </h3>
              </div>
            </GridItem>
          </GridContainer>
        </div>
      </Parallax>
      <br></br>
      <div className="center"><img src={Avientlogo} alt="Avient Logo" /></div>
      <br></br>
      <br></br>
      <div className="center style01home">Experience InstaColr on iPad - call your Avient representative</div>
      <br></br>
      <br></br>
      <HomCentContent image={require("assets/img/background2.jpg")} className="homecentbg">
        <div className={classes.container}>
          <GridContainer>
            <GridItem>
              <div className={centContClasses.boxes} style={{marginTop: "50px"}}>
                <div className={centContClasses.column1box}>
                <img src={placeholder1} alt="InstaColr commercial Requirements Masterbatch sample" className="responsive" /></div>
                <div className={centContClasses.column2box} style={{backgroundColor: "#fff", opacity: "0.7"}}>
                <h2 className={centContClasses.subtitle}>Enter Requirements</h2>
                <span className={centContClasses.subtitlecont}>From Processing temperature and light fastness to regulatory and production lead time, enter all the technical and commercial requirements you need for your Masterbatch sample.</span>
                </div>
              </div>                           
            </GridItem>
            <GridItem>
            <div className={centContClasses.boxes} style={{marginTop: "50px"}}>
                <div className={centContClasses.column3box}>
                <img src={placeholder2} alt="InstaColr Target Color" className="responsive" />
                </div> 
                <div className={centContClasses.column4box} style={{backgroundColor: "#fff", opacity: "0.7"}}>
                <h2 className={centContClasses.subtitle}>Select your Target Color</h2>
                <span className={centContClasses.subtitlecont}>Using the iPad camera and a proprietary color adjustment interface, define the exact color you need for your product.</span>
                </div>                               
            </div>
            </GridItem>
          </GridContainer>
        </div>
      </HomCentContent>
      <HomCentContent image={require("assets/img/background3.jpg")}  className="homecentbg">
        <div className={classes.container}>
          <GridContainer>
            <GridItem>
              <div className={centContClasses.boxes}>
                <div className={centContClasses.column1box}>
                <img src={placeholder3} alt="InstaColr Product Proposals" className="responsive" /></div>
                <div className={centContClasses.column2box} style={{backgroundColor: "#fff", opacity: "0.7"}}>
                <h2 className={centContClasses.subtitle}>You Have the Choice</h2>
                <span className={centContClasses.subtitlecont}>InstaColr's engine develops up to three releavnt and tailor-made proposals with associated price and specifications on the spot for you to choose.</span>
                </div>
              </div>                           
            </GridItem>
            <GridItem className={centContClasses.padspace}>
            <div className={centContClasses.boxes}>
                <div className={centContClasses.column3box}>
                <img src={placeholder4} alt="InstaColr Follow up actions request samples" className="responsive" />
                </div>
                <div className={centContClasses.column4box}>
                <h2 className={centContClasses.subtitle}>Request Samples</h2>
                <span className={centContClasses.subtitlecont}>Define the amount of Masterbatch sample you need and the Insatcolr regional laboratory will produce and ship it to you in 3-5 days.</span>
                </div>
                                                
            </div>
            </GridItem>
          </GridContainer>
        </div>
      </HomCentContent>
      <br></br>
      <div className="center padtopstyle01"><img src={AvientCLogo} alt="Avient Logo" /></div>
      <br></br>
      <hr className="hrlinestyle"></hr>
      <br></br>
      <div className="center style01home">Contact Our Team</div>
      <br></br>
      <div className="center">To learn more about InstaColr, email us at <a href="#" mailto="instacolr.support@clariant.com">instacolr.support@clariant.com</a></div>
      <br></br>
      <br></br><br></br>
      <Footer />
    </div>
  );
}
